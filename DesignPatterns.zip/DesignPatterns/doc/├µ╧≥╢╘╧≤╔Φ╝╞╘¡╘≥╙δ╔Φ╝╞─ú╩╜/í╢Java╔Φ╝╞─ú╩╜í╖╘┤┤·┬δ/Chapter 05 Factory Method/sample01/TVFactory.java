public interface TVFactory
{
    public TV produceTV();
}