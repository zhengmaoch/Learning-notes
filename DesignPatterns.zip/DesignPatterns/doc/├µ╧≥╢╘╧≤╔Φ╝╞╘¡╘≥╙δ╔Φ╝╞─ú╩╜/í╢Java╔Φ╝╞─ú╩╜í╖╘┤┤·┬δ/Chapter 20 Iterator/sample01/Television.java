public interface Television
{
	TVIterator createIterator();
}