public class PrintSpoolerException extends Exception 	
{
	public PrintSpoolerException(String message) 
	{	
		super(message);
	}
}