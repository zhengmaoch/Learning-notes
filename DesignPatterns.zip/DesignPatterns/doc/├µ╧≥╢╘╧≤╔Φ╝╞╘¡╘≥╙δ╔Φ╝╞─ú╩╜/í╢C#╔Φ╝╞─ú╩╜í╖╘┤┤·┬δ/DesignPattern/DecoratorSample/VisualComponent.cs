﻿namespace DecoratorSample
{
    abstract class VisualComponent
    {
        public abstract void Display();
    }
}