﻿namespace FactoryMethodSample
{
    interface LoggerFactory
    {
        Logger CreateLogger();
    }
}
