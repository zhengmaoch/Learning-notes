﻿namespace FactoryMethodSample
{
    interface Logger
    {
        void WriteLog();
    }
}