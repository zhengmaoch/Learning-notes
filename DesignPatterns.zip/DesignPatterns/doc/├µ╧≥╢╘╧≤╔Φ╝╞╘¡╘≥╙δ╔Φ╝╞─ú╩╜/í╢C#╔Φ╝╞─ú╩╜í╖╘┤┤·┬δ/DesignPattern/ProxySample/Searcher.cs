﻿namespace ProxySample
{
    interface Searcher
    {
        string DoSearch(string userId, string keyword);
    }
}
