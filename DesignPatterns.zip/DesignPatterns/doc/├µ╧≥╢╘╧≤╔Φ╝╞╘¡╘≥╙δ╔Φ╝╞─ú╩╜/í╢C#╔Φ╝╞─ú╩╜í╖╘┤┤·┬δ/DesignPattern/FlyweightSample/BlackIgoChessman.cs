﻿namespace FlyweightSample
{
    class BlackIgoChessman : IgoChessman
    {
        public override string GetColor()
        {
            return "黑色";
        }	
    }
}
