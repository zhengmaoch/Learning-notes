﻿namespace SimpleFactorySample
{
    interface Chart
    {
        void Display();
    }
}
