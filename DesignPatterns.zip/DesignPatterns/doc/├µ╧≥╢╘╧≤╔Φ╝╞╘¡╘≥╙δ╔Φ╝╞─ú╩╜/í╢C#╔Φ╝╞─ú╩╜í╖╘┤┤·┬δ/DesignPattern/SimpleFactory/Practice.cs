﻿namespace SimpleFactorySample
{
    /*
    abstract class Product
    {
        public abstract void Process();
    }

    class ConcreteProductA : Product
    {
        public override void Process()
        {
            //......
        }
    }

    class ConcreteProductB : Product
    {
        public override void Process()
        {
            //......
        }
    }

    class Factory
    {
        public static Product CreateProduct(char type)
        {
            switch(type)
            {
                case 'A':
                    return new ConcreteProductA(); break;
                case 'B':
                    return new ConcreteProductB(); break;
                //......
            }
        }
    }
    */
}
