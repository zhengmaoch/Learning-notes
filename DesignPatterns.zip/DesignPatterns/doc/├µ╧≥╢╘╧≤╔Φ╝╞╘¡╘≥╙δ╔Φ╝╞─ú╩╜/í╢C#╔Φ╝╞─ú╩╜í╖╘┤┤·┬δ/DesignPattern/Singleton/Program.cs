﻿using System;

namespace Singleton
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("两个对象是相同实例。");
            Console.Read();
        }
    }
}
