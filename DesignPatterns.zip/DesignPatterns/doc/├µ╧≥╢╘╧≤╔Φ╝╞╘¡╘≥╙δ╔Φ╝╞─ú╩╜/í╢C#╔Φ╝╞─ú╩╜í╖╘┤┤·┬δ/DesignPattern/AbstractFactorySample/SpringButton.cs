﻿using System;

namespace AbstractFactorySample
{
    class SpringButton : Button 
    {
	    public void Display() 
        {
		    Console.WriteLine("显示浅绿色按钮。");
	    }
    }
}
