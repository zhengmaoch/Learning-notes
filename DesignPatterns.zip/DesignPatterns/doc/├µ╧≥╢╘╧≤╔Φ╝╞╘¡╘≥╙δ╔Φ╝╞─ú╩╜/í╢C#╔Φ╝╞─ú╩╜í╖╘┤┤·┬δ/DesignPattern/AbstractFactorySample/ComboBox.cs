﻿namespace AbstractFactorySample
{
    interface ComboBox
    {
        void Display();
    }
}
