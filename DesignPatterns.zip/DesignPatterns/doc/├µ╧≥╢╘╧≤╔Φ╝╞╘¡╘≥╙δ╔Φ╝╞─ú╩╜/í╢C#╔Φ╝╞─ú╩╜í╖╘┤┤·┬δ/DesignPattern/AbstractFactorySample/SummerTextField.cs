﻿using System;

namespace AbstractFactorySample
{
    class SummerTextField : TextField 
    {
	    public void Display() 
        {
		    Console.WriteLine("显示蓝色边框文本框。");
	    }	
    }
}
