﻿namespace AbstractFactorySample
{
    interface Button
    {
        void Display();
    }
}
