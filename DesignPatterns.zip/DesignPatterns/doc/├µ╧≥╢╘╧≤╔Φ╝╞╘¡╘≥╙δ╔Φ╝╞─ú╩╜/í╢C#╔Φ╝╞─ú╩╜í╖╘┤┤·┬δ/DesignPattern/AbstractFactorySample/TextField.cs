﻿namespace AbstractFactorySample
{
    interface TextField
    {
        void Display();
    }
}