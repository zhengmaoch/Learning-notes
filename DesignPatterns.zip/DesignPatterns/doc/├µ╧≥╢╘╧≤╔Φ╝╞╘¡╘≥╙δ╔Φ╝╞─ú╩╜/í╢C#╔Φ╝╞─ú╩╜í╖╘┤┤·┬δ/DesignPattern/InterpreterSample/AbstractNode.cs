﻿namespace InterpreterSample
{
    abstract class AbstractNode
    {
        public abstract string Interpret();
    }
}
