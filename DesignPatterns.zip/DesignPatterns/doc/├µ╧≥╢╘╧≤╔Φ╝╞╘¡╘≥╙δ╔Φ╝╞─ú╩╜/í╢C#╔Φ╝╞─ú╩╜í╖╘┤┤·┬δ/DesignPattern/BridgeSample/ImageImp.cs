﻿namespace BridgeSample
{
    interface ImageImp
    {
        void DoPaint(Matrix m);  //显示像素矩阵m
    }
}
