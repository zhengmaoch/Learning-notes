﻿namespace BridgeSample
{
    class Matrix
    {
        //代码省略
    }
}
