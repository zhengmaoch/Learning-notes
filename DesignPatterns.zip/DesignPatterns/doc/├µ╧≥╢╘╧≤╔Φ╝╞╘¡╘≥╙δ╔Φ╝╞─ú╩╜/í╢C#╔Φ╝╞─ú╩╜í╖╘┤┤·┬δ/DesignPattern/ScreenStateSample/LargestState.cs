﻿using System;

namespace ScreenStateSample
{
    class LargestState : ScreenState
    {
        public override void Display()
        {
            Console.WriteLine("四倍大小！");
        }
    }
}
