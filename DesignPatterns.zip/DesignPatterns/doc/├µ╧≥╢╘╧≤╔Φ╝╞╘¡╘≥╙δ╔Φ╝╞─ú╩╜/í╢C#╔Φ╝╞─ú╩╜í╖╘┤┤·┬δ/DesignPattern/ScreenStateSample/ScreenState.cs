﻿using System;

namespace ScreenStateSample
{
    abstract class ScreenState
    {
        public abstract void Display();
    }
}
