﻿namespace StrategySample
{
    interface Discount
    {
        double Calculate(double price);
    }
}
