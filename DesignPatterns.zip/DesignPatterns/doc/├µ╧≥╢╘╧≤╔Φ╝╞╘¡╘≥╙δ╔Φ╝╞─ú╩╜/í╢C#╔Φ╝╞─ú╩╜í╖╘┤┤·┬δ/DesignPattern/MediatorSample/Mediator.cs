﻿namespace MediatorSample
{
    abstract class Mediator
    {
        public abstract void ComponentChanged(Component c);
    }
}
