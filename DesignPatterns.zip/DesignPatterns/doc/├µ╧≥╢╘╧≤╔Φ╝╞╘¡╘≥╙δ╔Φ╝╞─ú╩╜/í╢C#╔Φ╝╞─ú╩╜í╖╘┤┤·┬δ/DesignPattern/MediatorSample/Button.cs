﻿namespace MediatorSample
{
    class Button : Component 
    {
	    public override void Update() 
        {
		    //按钮不产生响应
	    }
    }
}
