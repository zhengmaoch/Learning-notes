﻿using System;

namespace CommandSample
{
    class SystemExitClass
    {
        public void Exit()
        {
            Console.WriteLine("退出系统！");
        }
    }
}
