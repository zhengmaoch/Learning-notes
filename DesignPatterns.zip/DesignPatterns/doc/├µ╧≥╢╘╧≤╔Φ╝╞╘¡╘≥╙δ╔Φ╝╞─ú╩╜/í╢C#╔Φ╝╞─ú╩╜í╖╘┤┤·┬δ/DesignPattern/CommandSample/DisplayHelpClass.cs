﻿using System;

namespace CommandSample
{
    class DisplayHelpClass
    {
        public void Display()
        {
            Console.WriteLine("显示帮助文档！");
        }
    }
}
