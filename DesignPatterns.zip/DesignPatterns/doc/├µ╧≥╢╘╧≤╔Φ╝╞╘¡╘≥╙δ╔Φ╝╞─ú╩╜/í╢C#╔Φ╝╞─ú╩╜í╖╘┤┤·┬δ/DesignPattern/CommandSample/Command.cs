﻿namespace CommandSample
{
    abstract class Command
    {
        public abstract void Execute();
    }
}
